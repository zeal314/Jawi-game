# ProGuard rules for Kembara Jawi 3D
